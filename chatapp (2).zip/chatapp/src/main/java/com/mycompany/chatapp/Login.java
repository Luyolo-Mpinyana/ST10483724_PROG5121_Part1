/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java
 */
package com.mycompany.chatapp;

import java.util.regex.Pattern;

public class Login {

    private String username;
    private String password;
    private String phoneNumber;

    // USERNAME VALIDATION
    public boolean checkUserName(String username) {
        return username != null && username.contains("_") && username.length() <= 5;
    }

    // PASSWORD VALIDATION
    public boolean checkPasswordComplexity(String password) {
        if (password == null) return false;

        boolean hasUpperCase = false;
        boolean hasNumber = false;
        boolean hasSpecialChar = false;

        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                hasUpperCase = true;
            }
            if (Character.isDigit(c)) {
                hasNumber = true;
            }
            if (!Character.isLetterOrDigit(c)) {
                hasSpecialChar = true;
            }
        }

        return password.length() >= 8 && hasUpperCase && hasNumber && hasSpecialChar;
    }

    // PHONE NUMBER VALIDATION (Upgraded with Rubric-Required Regex)
    public boolean checkCellPhoneNumber(String phoneNumber) {
        if (phoneNumber == null) return false;
        // Regex ensures it starts with +27 followed by exactly 1 to 9 digits (max length 12 total)
        String regex = "^\\+27\\d{1,9}$";
        return Pattern.matches(regex, phoneNumber) && phoneNumber.length() <= 12;
    }

    // REGISTER USER
    public String registerUser(String username, String password, String phoneNumber) {

        if (!checkUserName(username)) {
            return "Username is not correctly formatted; please ensure it contains an underscore and is no more than 5 characters.";
        }

        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted; must contain 8 characters, a capital letter, a number, and a special character.";
        }

        if (!checkCellPhoneNumber(phoneNumber)) {
            return "Cell phone number incorrectly formatted or does not contain international code.";            
        }  
        
        this.username = username;
        this.password = password;
        this.phoneNumber = phoneNumber;

        return "User registered successfully.";
    }

    // LOGIN USER
    public boolean loginUser(String username, String password) {
        return this.username != null && this.password != null &&
               this.username.equals(username) && this.password.equals(password);
    }

    // LOGIN STATUS MESSAGE
    public String returnLoginStatus(boolean status) {
        if (status) {
            return "Login successful. Welcome, it is a pleasure to have you here!!";
        } else {
            return "Login failed. Username or password incorrect.";
        }
    }
}