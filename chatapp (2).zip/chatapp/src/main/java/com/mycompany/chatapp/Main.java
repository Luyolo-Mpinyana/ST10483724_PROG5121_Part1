package com.mycompany.chatapp;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Login login = new Login();
        Message message = new Message();

        // --- PART 1: Registration ---
        System.out.println("=== WELCOME TO CHATAPP === ");
        System.out.println("=== REGISTRATION ===");
        System.out.print("Enter username (must contain a _ and 5 characters max): ");
        String username = input.nextLine();
        System.out.print("Enter password: ");
        String password = input.nextLine();
        System.out.print("Enter phone number (+27...): ");
        String phone = input.nextLine();

        String registerMessage = login.registerUser(username, password, phone);
        System.out.println(registerMessage);

        // --- PART 1: Login ---
        System.out.println("\n=== LOGIN ===");
        System.out.print("Enter username: ");
        String loginUser = input.nextLine();
        System.out.print("Enter password: ");
        String loginPass = input.nextLine();

        boolean loginStatus = login.loginUser(loginUser, loginPass);
        System.out.println(login.returnLoginStatus(loginStatus));

        // --- PART 2 & 3: Messaging & Analytics Menu (Login Gate) ---
        if (loginStatus) {
            System.out.println("\nWelcome to ChatApp, " + loginUser + "!");
            boolean running = true;
            
            while (running) {
                System.out.println("\n=== CHAT MENU ===");
                System.out.println("1. Send Message");
                System.out.println("2. View All Messages");
                System.out.println("3. View My Messages");
                System.out.println("4. Display Longest Message");
                System.out.println("5. Search Message by Target ID");
                System.out.println("6. Search Messages by Recipient");
                System.out.println("7. Delete Message by Content Text");
                System.out.println("8. Display System Report");
                System.out.println("9. Logout");
                System.out.print("Choose an option: ");
                
                int choice = input.nextInt();
                input.nextLine(); // Consume newline

                switch (choice) {
                    case 1 -> {
                        System.out.print("Enter recipient username or phone: ");
                        String recipient = input.nextLine();
                        System.out.print("Enter your message: ");
                        String msgContent = input.nextLine();
                        
                        String result = message.sendMessage(loginUser, recipient, msgContent);
                        System.out.println(result);
                    }
                        
                    case 2 -> {
                        System.out.println("\n=== ALL MESSAGES ===");
                        System.out.println(message.getAllMessages());
                    }
                        
                    case 3 -> {
                        System.out.println("\n=== MY MESSAGES ===");
                        System.out.println(message.getMessagesForUser(loginUser));
                    }

                    case 4 -> {
                        System.out.println("\n=== LONGEST MESSAGE ===");
                        System.out.println(message.displayLongestMessage());
                    }

                    case 5 -> {
                        System.out.print("Enter Tracking/Target ID to scan: ");
                        String targetId = input.nextLine();
                        System.out.println("\n=== SEARCH RESULTS ===");
                        System.out.println(message.searchForMessageID(targetId));
                    }

                    case 6 -> {
                        System.out.print("Enter recipient to filter by: ");
                        String recipient = input.nextLine();
                        System.out.println("\n=== SEARCH RESULTS ===");
                        System.out.println(message.searchByRecipient(recipient));
                    }

                    case 7 -> {
                        System.out.print("Enter exact message content text to delete: ");
                        String deleteKeyword = input.nextLine();
                        System.out.println("\n=== DELETION STATUS ===");
                        System.out.println(message.deleteMessageByHash(deleteKeyword));
                    }

                    case 8 -> {
                        System.out.println("\n" + message.displayReport());
                    }
                        
                    case 9 -> {
                        System.out.println("Logging out... Exiting application cleanly.");
                        running = false;
                    }
                        
                    default -> System.out.println("Invalid option. Please try again using options 1-9.");
                }
            }
        } else {
            System.out.println("Login failed. Exiting application.");
        }
        
        input.close();
    }
}