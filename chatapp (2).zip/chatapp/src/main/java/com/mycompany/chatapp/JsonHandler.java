/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author j9luy
 */
package com.mycompany.chatapp;

import java.util.ArrayList;
import java.util.List;


public class JsonHandler {

    /**
     * Serializes a list of message records into a formatted JSON array string.
     */
    public static String serializeMessages(List<Message.MessageRecord> records) {
        StringBuilder sb = new StringBuilder();
        sb.append("[\n");
        
        for (int i = 0; i < records.size(); i++) {
            Message.MessageRecord msg = records.get(i);
            sb.append("  {\n");
            sb.append("    \"id\": \"").append(escapeJson(msg.id)).append("\",\n");
            sb.append("    \"sender\": \"").append(escapeJson(msg.sender)).append("\",\n");
            sb.append("    \"recipient\": \"").append(escapeJson(msg.recipient)).append("\",\n");
            sb.append("    \"content\": \"").append(escapeJson(msg.content)).append("\",\n");
            sb.append("    \"timestamp\": \"").append(escapeJson(msg.timestamp)).append("\",\n");
            sb.append("    \"messageHash\": ").append(msg.messageHash).append("\n");
            sb.append("  }");
            
            if (i < records.size() - 1) {
                sb.append(",");
            }
            sb.append("\n");
        }
        
        sb.append("]");
        return sb.toString();
    }

    /**
     * Helper to safely escape characters like quotes and newlines for clean JSON formatting.
     */
    private static String escapeJson(String input) {
        if (input == null) return "";
        return input.replace("\\", "\\\\")
                    .replace("\"", "\\\"")
                    .replace("\n", "\\n")
                    .replace("\r", "\\r");
    }

    /**
     * Helper to clean up escaped JSON characters back to clear standard layout.
     */
    private static String unescapeJson(String input) {
        if (input == null) return "";
        return input.replace("\\\"", "\"")
                    .replace("\\\\", "\\")
                    .replace("\\n", "\n")
                    .replace("\\r", "\r");
    }

    /**
     * Parses a raw JSON array string back into structurally organized live records.
     */
    public static List<Message.MessageRecord> deserializeMessages(String jsonText, Message messageInstance) {
        List<Message.MessageRecord> list = new ArrayList<>();
        if (jsonText == null || jsonText.trim().isEmpty() || !jsonText.contains("{")) {
            return list;
        }

        // Split data into individual objects blocks bounded by braces {}
        String[] objects = jsonText.split("\\{");
        
        for (String obj : objects) {
            if (!obj.contains("}")) continue;
            
            // Extract field values sequentially via clean token boundary scanning
            String id = extractValue(obj, "id");
            String sender = extractValue(obj, "sender");
            String recipient = extractValue(obj, "recipient");
            String content = extractValue(obj, "content");
            String timestamp = extractValue(obj, "timestamp");

            if (!sender.isEmpty() && !recipient.isEmpty()) {
                Message.MessageRecord record = messageInstance.new MessageRecord(id, sender, recipient, content, timestamp);
                list.add(record);
            }
        }
        return list;
    }

    /**
     * Safely isolates values inside targeted keys.
     */
    private static String extractValue(String block, String key) {
        String searchKey = "\"" + key + "\":";
        int index = block.indexOf(searchKey);
        if (index == -1) return "";

        int startPos = block.indexOf("\"", index + searchKey.length());
        if (startPos == -1) return "";
        
        int endPos = block.indexOf("\"", startPos + 1);
        if (endPos == -1) return "";

        return unescapeJson(block.substring(startPos + 1, endPos));
    }
}