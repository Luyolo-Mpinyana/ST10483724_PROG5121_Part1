/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java
 */

package com.mycompany.chatpart1;

import com.mycompany.chatapp.Message;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.*;
import java.io.File;

public class MessageTest {
    
    private Message message;

    /**
     * Initializes a new message object before each test execution.
     */
    @BeforeEach
    public void setUp() {
        message = new Message();
        message.clearMessages(); 
    }
    
    @Test
    public void testSendMessageSuccess() {
        String result = message.sendMessage("user1", "user2", "Hello World");
        assertTrue(result.contains("Message sent successfully"));
        assertEquals(1, message.getMessageCount());
    }
    
    @Test
    public void testSendMessageEmptyContent() {
        String result = message.sendMessage("user1", "user2", "");
        assertTrue(result.contains("Error"));
        assertTrue(result.contains("cannot be empty"));
    }
    
    @Test
    public void testSendMessageToSelf() {
        String result = message.sendMessage("user1", "user1", "Hello");
        assertTrue(result.contains("Error"));
        assertTrue(result.contains("Cannot send message to yourself"));
    }
    
    @Test
    public void testGetAllMessagesEmpty() {
        String result = message.getAllMessages();
        assertTrue(result.contains("No messages found"));
    }
    
    @Test
    public void testGetAllMessagesWithMessages() {
        message.sendMessage("user1", "user2", "Message 1");
        message.sendMessage("user3", "user1", "Message 2");
        
        String result = message.getAllMessages();
        assertTrue(result.contains("user1"));
        assertTrue(result.contains("user2"));
        assertTrue(result.contains("Message 1"));
        assertTrue(result.contains("Message 2"));
    }
    
    @Test
    public void testGetMessagesForUser() {
        message.sendMessage("user1", "user2", "Hello user2");
        message.sendMessage("user2", "user1", "Hello user1");
        message.sendMessage("user3", "user4", "Unrelated message");
        
        String user1Messages = message.getMessagesForUser("user1");
        assertTrue(user1Messages.contains("Hello user2"));
        assertTrue(user1Messages.contains("Hello user1"));
        assertFalse(user1Messages.contains("Unrelated message"));
    }
    
    @Test
    public void testGetMessagesForUserNoMessages() {
        String result = message.getMessagesForUser("nonexistent");
        assertTrue(result.contains("No messages found"));
    }
    
    @Test
    public void testMessageCount() {
        assertEquals(0, message.getMessageCount());
        
        message.sendMessage("user1", "user2", "Msg 1");
        assertEquals(1, message.getMessageCount());
        
        message.sendMessage("user1", "user3", "Msg 2");
        assertEquals(2, message.getMessageCount());
    }
    
    @Test
    public void testMessagesPersistToFile() {
        message.sendMessage("user1", "user2", "Persistent message");
        
        Message message2 = new Message();
        assertEquals(1, message2.getMessageCount());
        
        String allMessages = message2.getAllMessages();
        assertTrue(allMessages.contains("Persistent message"));
    }
    
    @Test
    public void testMessageTimestamp() {
        message.sendMessage("user1", "user2", "Test message");
        String allMessages = message.getAllMessages();
        
        // Matches typical YYYY-MM-DD HH:MM:SS format
        assertTrue(allMessages.matches(".*\\d{4}-\\d{2}-\\d{2} \\d{2}:\\d{2}:\\d{2}.*"));
    }
    
    @Test
    public void testClearMessages() {
        message.sendMessage("user1", "user2", "Msg 1");
        message.sendMessage("user1", "user2", "Msg 2");
        assertEquals(2, message.getMessageCount());
        
        message.clearMessages();
        assertEquals(0, message.getMessageCount());
        
        File file = new File("messages.json");
        assertFalse(file.exists());
    }

    @Test
    public void testSentMessagesArrayPopulated() {
        message.sendMessage("user1", "user2", "Test message 1");
        assertNotNull(message.getSentMessagesArray());
        assertEquals(1, message.getSentMessagesArray().size());
        assertEquals("Test message 1", message.getSentMessagesArray().get(0).content);
    }
    
    @Test
    public void testDisplayLongestMessage() {
        message.sendMessage("user1", "user2", "Short");
        message.sendMessage("user1", "user2", "Where are you? You are late! I have asked you to be on time");
        message.sendMessage("user1", "user2", "Medium text line");
        
        String result = message.displayLongestMessage();
        assertTrue(result.contains("Where are you? You are late!"));
    }
    
    @Test
    public void testSearchForMessageID() {
        // Formats to fallback target ID matching rules when no country code is present
        message.sendMessage("user1", "user2", "Tracking identity verified");
        String result = message.searchForMessageID("0838884567");
        assertTrue(result.contains("Tracking identity verified"));
    }
    
    @Test
    public void testSearchByRecipient() {
        message.sendMessage("user1", "+27838884567", "Hello content");
        String result = message.searchByRecipient("+27838884567");
        assertTrue(result.contains("Hello content"));
    }
    
    @Test
    public void testDeleteMessageByHash() {
        message.sendMessage("user1", "user2", "Where are you? You are late! I have asked you to be on time");
        String result = message.deleteMessageByHash("Where are you? You are late! I have asked you to be on time");
        
        // Verifies against the explicit confirmation pattern on your rubric sheets
        assertTrue(result.contains("successfully deleted"));
        assertEquals(0, message.getMessageCount());
    }
    
    @Test
    public void testDisplayReport() {
        message.sendMessage("user1", "user2", "Report logging content data");
        String report = message.displayReport();
        
        assertTrue(report.contains("SYSTEM MESSAGE REPORT"));
        assertTrue(report.contains("Message Hash:"));
        assertTrue(report.contains("Recipient:"));
        assertTrue(report.contains("Message:"));
    }
}