package com.mycompany.chatpart1;

import com.mycompany.chatapp.Login;
import org.junit.jupiter.api.Test;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 * @author Student
 */
public class LoginTest {
    
    private final Login login = new Login();
   
    // ==================== checkUserName Tests ====================
    
    @Test
    public void testCheckUserName_Valid_WithUnderscoreAndShort() {
        assertTrue(login.checkUserName("ky_l"));
    }
    
    @Test
    public void testCheckUserName_Valid_ExactMaxLength() {
        assertTrue(login.checkUserName("kyl_1")); 
    }
    
    @Test
    public void testCheckUserName_Invalid_NoUnderscore() {
        assertFalse(login.checkUserName("kyle"));
    }
    
    @Test
    public void testCheckUserName_Invalid_TooLong() {
        assertFalse(login.checkUserName("kyle_long_username"));
    }
    
    @Test
    public void testCheckUserName_Invalid_EmptyString() {
        assertFalse(login.checkUserName(""));
    }
    
    @Test
    public void testCheckUserName_Invalid_Null() {
        assertFalse(login.checkUserName(null));
    }
    
    // ==================== checkPasswordComplexity Tests ====================
    
    @Test
    public void testCheckPasswordComplexity_Valid_Basic() {
        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));
    }
    
    @Test
    public void testCheckPasswordComplexity_Invalid_NoCapital() {
        assertFalse(login.checkPasswordComplexity("password123!"));
    }
    
    @Test
    public void testCheckPasswordComplexity_Invalid_Empty() {
        assertFalse(login.checkPasswordComplexity(""));
    }
    
    @Test
    public void testCheckPasswordComplexity_Invalid_OnlyCapital() {
        assertFalse(login.checkPasswordComplexity("ABC"));
    }
    
    @Test
    public void testCheckPasswordComplexity_Invalid_OnlyNumbers() {
        assertFalse(login.checkPasswordComplexity("12345"));
    }
    
    @Test
    public void testCheckPasswordComplexity_Invalid_Null() {
        assertFalse(login.checkPasswordComplexity(null));
    }
    
    // ==================== checkCellPhoneNumber Regex Tests ====================
    
    @Test
    public void testCheckCellPhoneNumber_Valid_StandardSA() {
        assertTrue(login.checkCellPhoneNumber("+27813990583")); // Valid format and <= 12 characters
    }
    
    @Test
    public void testCheckCellPhoneNumber_Valid_ShorterNumber() {
        assertTrue(login.checkCellPhoneNumber("+2712345")); // Matches regex and <= 12 characters
    }
    
    @Test
    public void testCheckCellPhoneNumber_Invalid_WrongCountryCode() {
        assertFalse(login.checkCellPhoneNumber("+11234567890"));
    }
    
    @Test
    public void testCheckCellPhoneNumber_Invalid_TooLong() {
        assertFalse(login.checkCellPhoneNumber("+271234567891011"));
    }

    @Test
    public void testCheckCellPhoneNumber_Invalid_NoPlusSign() {
        assertFalse(login.checkCellPhoneNumber("27813990583"));
    }

    @Test
    public void testCheckCellPhoneNumber_Invalid_Null() {
        assertFalse(login.checkCellPhoneNumber(null));
    }
}