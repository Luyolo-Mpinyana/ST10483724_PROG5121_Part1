/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.chatpart1;

/**
 *
 * @author Student
 */
/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
import com.mycompany.chatapp.Login;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions.*;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 *
 * @author Student
 */
public class LoginTest {
    
    Login login = new Login();
   
    // ==================== checkUserName Tests ====================
    
    @Test
    public void testCheckUserName_Valid_WithUnderscoreAndShort() {
        assertTrue(login.checkUserName("ky_l"));
    }
    
    @Test
    public void testCheckUserName_Valid_ExactMaxLength() {
        assertTrue(login.checkUserName("kyl_1")); 
    }
    
    @Test
    public void testCheckUserName_Invalid_NoUnderscore() {
        assertFalse(login.checkUserName("kyle!!!!!!"));
    }
    
    @Test
    public void testCheckUserName_Invalid_TooLong() {
        assertFalse(login.checkUserName("kyle!!!!!!!")); // 7 chars
    }
    
    @Test
    public void testCheckUserName_Invalid_EmptyString() {
        assertFalse(login.checkUserName(""));
    }
    
    @Test
    public void testCheckUserName_Invalid_OnlyUnderscore() {
        assertTrue(login.checkUserName("_")); // 1 char, contains underscore
    }
    
    
    @Test
    public void testCheckPasswordComplexity_Valid_Basic() {
        
        assertTrue(login.checkPasswordComplexity("Ch&&sec@ke99!"));
    }
    
    @Test
    public void testCheckPasswordComplexity_Invalid_NoCapital() {
        assertFalse(login.checkPasswordComplexity("password"));
    }
    
    @Test
    public void testCheckPasswordComplexity_Invalid_Empty() {
        // password.length() >= 0 is always true, but loops won't set flags
        assertFalse(login.checkPasswordComplexity(""));
    }
    
    @Test
    public void testCheckPasswordComplexity_Invalid_OnlyCapital() {
        assertFalse(login.checkPasswordComplexity("ABC"));
    }
    
    @Test
    public void testCheckPasswordComplexity_Invalid_OnlyNumbers() {
        assertFalse(login.checkPasswordComplexity("12345"));
    }
    
    // ==================== checkCellPhoneNumber Tests ====================
    
    @Test
    public void testCheckCellPhoneNumber_Valid_StandardSA() {
        assertTrue(login.checkCellPhoneNumber("+27813080583")); // 12 chars total
    }
    
    @Test
    public void testCheckCellPhoneNumber_Valid_ShorterNumber() {
        assertTrue(login.checkCellPhoneNumber("+2712345")); // 9 chars, <=12
    }
    
    @Test
    public void testCheckCellPhoneNumber_Invalid_WrongCountryCode() {
        assertFalse(login.checkCellPhoneNumber("+11234567890"));
    }
    
    @Test
    public void testCheckCellPhoneNumber_Invalid_TooLong() {
        assertFalse(login.checkCellPhoneNumber("+271234567891011"));

    }
}
