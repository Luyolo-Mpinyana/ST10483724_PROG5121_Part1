package com.mycompany.chatapp;

import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import org.json.JSONArray;
import org.json.JSONObject;

public class Message {
    private static final String MESSAGES_FILE = "messages.json";
    private List<MessageRecord> messages;

    public Message() {
        this.messages = loadMessages();
    }

    private class MessageRecord {
        String sender;
        String recipient;
        String content;
        String timestamp;

        MessageRecord(String sender, String recipient, String content, String timestamp) {
            this.sender = sender;
            this.recipient = recipient;
            this.content = content;
            this.timestamp = timestamp;
        }
    }

    public String sendMessage(String sender, String recipient, String content) {
        if (content == null || content.trim().isEmpty()) {
            return "Error: Message cannot be empty.";
        }

        if (sender.equals(recipient)) {
            return "Error: Cannot send message to yourself.";
        }

        LocalDateTime now = LocalDateTime.now();
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
        String timestamp = now.format(formatter);

        messages.add(new MessageRecord(sender, recipient, content, timestamp));
        saveMessages();

        return "Message sent successfully to " + recipient + " at " + timestamp;
    }

    public String getAllMessages() {
        if (messages.isEmpty()) {
            return "No messages found.";
        }

        StringBuilder sb = new StringBuilder();
        for (MessageRecord msg : messages) {
            sb.append("From: ").append(msg.sender)
              .append(" | To: ").append(msg.recipient)
              .append(" | Time: ").append(msg.timestamp)
              .append("\n")
              .append("Message: ").append(msg.content)
              .append("\n")
              .append("--------------------\n");
        }
        return sb.toString();
    }

    public String getMessagesForUser(String username) {
        if (messages.isEmpty()) {
            return "No messages found for " + username + ".";
        }

        StringBuilder sb = new StringBuilder();
        int count = 0;
        
        for (MessageRecord msg : messages) {
            if (msg.sender.equals(username) || msg.recipient.equals(username)) {
                count++;
                sb.append("From: ").append(msg.sender)
                  .append(" | To: ").append(msg.recipient)
                  .append(" | Time: ").append(msg.timestamp)
                  .append("\n")
                  .append("Message: ").append(msg.content)
                  .append("\n")
                  .append("--------------------\n");
            }
        }

        if (count == 0) {
            return "No messages found for " + username + ".";
        }

        return sb.toString();
    }

    private List<MessageRecord> loadMessages() {
        List<MessageRecord> loadedMessages = new ArrayList<>();
        File file = new File(MESSAGES_FILE);

        if (!file.exists()) {
            return loadedMessages;
        }

        try {
            String content = new String(Files.readAllBytes(Paths.get(MESSAGES_FILE)));
            JSONArray jsonArray = new JSONArray(content);

            for (int i = 0; i < jsonArray.length(); i++) {
                JSONObject obj = jsonArray.getJSONObject(i);
                loadedMessages.add(new MessageRecord(
                    obj.getString("sender"),
                    obj.getString("recipient"),
                    obj.getString("content"),
                    obj.getString("timestamp")
                ));
            }
        } catch (IOException e) {
            System.err.println("Error loading messages: " + e.getMessage());
        }

        return loadedMessages;
    }

    private void saveMessages() {
        JSONArray jsonArray = new JSONArray();

        for (MessageRecord msg : messages) {
            JSONObject obj = new JSONObject();
            obj.put("sender", msg.sender);
            obj.put("recipient", msg.recipient);
            obj.put("content", msg.content);
            obj.put("timestamp", msg.timestamp);
            jsonArray.put(obj);
        }

        try (FileWriter writer = new FileWriter(MESSAGES_FILE)) {
            writer.write(jsonArray.toString(2));
            writer.flush();
        } catch (IOException e) {
            System.err.println("Error saving messages: " + e.getMessage());
        }
    }

    public int getMessageCount() {
        return messages.size();
    }

    public void clearMessages() {
        messages.clear();
        File file = new File(MESSAGES_FILE);
        if (file.exists()) {
            file.delete();
        }
    }
}