package com.mycompany.chatapp;

import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner input;
        input = new Scanner(System.in);
        Login login = new Login();
        Message message = new Message();

        // --- PART 1: Registration ---
        System.out.println("=== REGISTRATION ===");
        System.out.print("Enter username: ");
        String username = input.nextLine();
        System.out.print("Enter password: ");
        String password = input.nextLine();
        System.out.print("Enter phone number (+27...): ");
        String phone = input.nextLine();

        String registerMessage = login.registerUser(username, password, phone);
        System.out.println(registerMessage);

        // --- PART 1: Login ---
        System.out.println("\n=== LOGIN ===");
        System.out.print("Enter username: ");
        String loginUser = input.nextLine();
        System.out.print("Enter password: ");
        String loginPass = input.nextLine();

        boolean loginStatus = login.loginUser(loginUser, loginPass);
        System.out.println(login.returnLoginStatus(loginStatus));

        // --- PART 2: Messaging Menu (Login Gate) ---
        if (loginStatus) {
            System.out.println("\nWelcome to ChatApp, " + loginUser + "!");
            boolean running = true;
            
            while (running) {
                System.out.println("\n=== CHAT MENU ===");
                System.out.println("1. Send Message");
                System.out.println("2. View All Messages");
                System.out.println("3. View My Messages");
                System.out.println("4. Logout");
                System.out.print("Choose an option: ");
                
                int choice = input.nextInt();
                input.nextLine(); // Consume newline

                switch (choice) {
                    case 1 -> {
                        System.out.print("Enter recipient username: ");
                        String recipient = input.nextLine();
                        System.out.print("Enter your message: ");
                        String msgContent = input.nextLine();
                        
                        String result = message.sendMessage(loginUser, recipient, msgContent);
                        System.out.println(result);
                    }
                        
                    case 2 -> {
                        System.out.println("=== ALL MESSAGES ===");
                        System.out.println(message.getAllMessages());
                    }
                        
                    case 3 -> {
                        System.out.println("=== MY MESSAGES ===");
                        System.out.println(message.getMessagesForUser(loginUser));
                    }
                        
                    case 4 -> {
                        System.out.println("Logging out...");
                        running = false;
                    }
                        
                    default -> System.out.println("Invalid option. Please try again.");
                }
            }
        } else {
            System.out.println("Login failed. Exiting application.");
        }
        
        input.close();
    }
}