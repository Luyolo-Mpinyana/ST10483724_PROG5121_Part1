package com.mycompany.chatapp;

import java.util.Scanner;

public class MainApp {

    public static void main(String[] args) {

        Scanner input = new Scanner(System.in);

        Login login = new Login();

        // REGISTRATION
        System.out.println("=== REGISTRATION ===");

        System.out.print("Enter username: ");
        String username = input.nextLine();

        System.out.print("Enter password: ");
        String password = input.nextLine();

        System.out.print("Enter phone number (+27...): ");
        String phone = input.nextLine();

        String registerMessage = login.registerUser(username, password, phone);
        System.out.println(registerMessage);
       
        // LOGIN
        System.out.println("\n=== LOGIN ===");

        System.out.print("Enter username: ");
        String loginUser = input.nextLine();

        System.out.print("Enter password: ");
        String loginPass = input.nextLine();
       
        boolean loginStatus = login.loginUser(loginUser, loginPass);

        System.out.println(login.returnLoginStatus(loginStatus));
        
        input.close();
    }
}